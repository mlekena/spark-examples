Requirements:
To run this script, simply place this directory into the spark-test/test-python directory.
Then run the test.sh script. For the full dataset, replace the file data-fraction.csv with the full set.
