from __future__ import print_function

import sys
from operator import add
from pyspark.sql import SparkSession
from pyspark import SparkContext
from pyspark.sql.functions import concat, col, lit


reload(sys) 
sys.setdefaultencoding('utf8')
if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: wordcount <file>", file=sys.stderr)
        sys.exit(-1)

    spark = SparkSession.builder.appName("lab2Q3").getOrCreate()

    def upper_clean_str(x):
        if x == None:
            x = "NoColor"
        elif x in ['BK', 'BL', 'BLK', 'BK.', 'B', 'BK/', 'BKBL', 'DKBL', 'BL.', 'BLBL','BKL', 'B LAC', 'BK NO', 'BK+', 'BK1', 'BKBK', 'BLA', 'BLAC', 'BLAK', 'BLCK', ]:
            x = "BLACK"
        elif x in ['GY', 'GR', 'GRY', 'GL', 'GRAY','LTGY', 'LTG', 'DKGY', 'GYGY','DKGR', 'GRGY', 'GYGR','GY.', 'GY/', 'G']:
            x = "GREY"
        elif x in ['WH', 'WHI', 'WH/', 'WH.', 'WHIT', 'WHT','WHTE', 'WHT.', 'WHTIE', 'WHTN','WHWH','WT', 'WT.', 'White', 'W']:
            x = "WHITE"
        elif x in ['YELLO', 'YEL', 'YELL', 'YW']:
            x ='YELLOW'
        elif x in ['SIL', 'SILVE', 'SILV', 'SL', 'SL.','SLV', 'SLVR']:
            x = "SILVER"
        elif x in ['BLU']:
            x = 'BLUE'
        elif x in ['RD', 'R']:
            x ="RED"
        elif x in ['BRN', 'BRO', 'BRW','BR']:
            x = "BROWN"
        elif x in ['TN', 'T']:
            x = 'TAN'
        elif x == 'GRN':
            x = 'GREEN'
        elif x[:3] in ['MAR', 'MR', 'M']:
            x = 'MAROON'
        elif x[:2] in ['ON', 'OR']:
            x = 'ORANGE'
        punc='!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'
        uppercased_str = x.upper()
        for ch in punc:
            uppercased_str = uppercased_str.replace(ch, '')
        return uppercased_str

    data = spark.read.option("header",True).csv(sys.argv[1])
    CL = data.select("Vehicle Color").rdd.map(lambda row : row[0]).map(upper_clean_str).collect()

    counts = spark.sparkContext.parallelize(CL, 3).map(lambda x: (x, 1))\
    .reduceByKey(lambda x,y: x+y).map(lambda x: (x[1], x[0])).sortByKey(False)

    counts.saveAsTextFile("./CL_output")
    output = counts.collect()

    for (count, word) in output:
        print("%i: %s" % (count, word))


#3level of parallelism 
    print("Paralellism 3")
    counts = spark.sparkContext.parallelize(CL, 3).map(lambda x: (x, 1))\
    .reduceByKey(lambda x,y: x+y).map(lambda x: (x[1], x[0])).sortByKey(False)

    counts.saveAsTextFile("hdfs://10.128.0.8:9000/Lab2_Q3/outputP3")
    output = counts.collect()

    for (count, word) in output:
        print("%i: %s" % (count, word))

#4level of parallelism 
    print("Paralellism 4")
    counts = spark.sparkContext.parallelize(CL, 4).map(lambda x: (x, 1))\
    .reduceByKey(lambda x,y: x+y).map(lambda x: (x[1], x[0])).sortByKey(False)

    counts.saveAsTextFile("hdfs://10.128.0.8:9000/Lab2_Q3/outputP4")
    output = counts.collect()

    for (count, word) in output:
        print("%i: %s" % (count, word))

#5level of parallelism 
    print("Paralellism 5")
    counts = spark.sparkContext.parallelize(CL, 5).map(lambda x: (x, 1))\
    .reduceByKey(lambda x,y: x+y).map(lambda x: (x[1], x[0])).sortByKey(False)

    counts.saveAsTextFile("hdfs://10.128.0.8:9000/Lab2_Q3/outputP5")
    output = counts.collect()

    for (count, word) in output:
        print("%i: %s" % (count, word))
        
    spark.stop()