from __future__ import print_function

import sys
from operator import add
from pyspark.sql import SparkSession
from pyspark import SparkContext
from pyspark import SparkConf
from pyspark.sql.functions import concat, col, lit



reload(sys) 
sys.setdefaultencoding('utf8')
if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: wordcount <file>", file=sys.stderr)
        sys.exit(-1)

    spark = SparkSession.builder.appName("lab2Q3").getOrCreate()

    def clean_time(t):
        if t == None:
            t = "NoTime"
        time = t[:2]+"00"+t[-1]
        return time 

    data = spark.read.option("header",True).csv(sys.argv[1])
    T = data.select("Violation Time").rdd.map(lambda row : row[0]).map(clean_time).collect()

    
#2level of parallelism 
    print("Paralellism 2")
    counts = spark.sparkContext.parallelize(T, 2).map(lambda x: (x, 1))\
    .reduceByKey(lambda x,y: x+y).map(lambda x: (x[1], x[0])).sortByKey(False)

    counts.saveAsTextFile("hdfs://10.128.0.8:9000/Lab2_Q3/outputP2")
    output = counts.collect()

 
    for (count, word) in output:
        print("%i: %s" % (count, word))


#3 level of parallelism 
    print("Paralellism 3")
    counts = spark.sparkContext.parallelize(T, 3).map(lambda x: (x, 1))\
    .reduceByKey(lambda x,y: x+y).map(lambda x: (x[1], x[0])).sortByKey(False)

    counts.saveAsTextFile("hdfs://10.128.0.8:9000/Lab2_Q3/outputP3")
    output = counts.collect()

 
    for (count, word) in output:
        print("%i: %s" % (count, word))

# 4level of parallelism
    print("Paralellism 4")
    counts = spark.sparkContext.parallelize(T, 4).map(lambda x: (x, 1))\
    .reduceByKey(lambda x,y: x+y).map(lambda x: (x[1], x[0])).sortByKey(False)

    counts.saveAsTextFile("hdfs://10.128.0.8:9000/Lab2_Q3/outputP4")
    output = counts.collect()

 
    for (count, word) in output:
        print("%i: %s" % (count, word))

# 5level of parallelism
    print("Paralellism 4")
    counts = spark.sparkContext.parallelize(T, 5).map(lambda x: (x, 1))\
    .reduceByKey(lambda x,y: x+y).map(lambda x: (x[1], x[0])).sortByKey(False)

    counts.saveAsTextFile("hdfs://10.128.0.8:9000/Lab2_Q3/outputP5")
    output = counts.collect()

 
    for (count, word) in output:
        print("%i: %s" % (count, word))

    spark.stop()

