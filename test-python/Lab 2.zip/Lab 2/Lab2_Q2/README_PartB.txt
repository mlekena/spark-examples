####################################################################

### README LAB 2 PART B       Modupe Lekena, Dylan Smith, Suzanne Zhen

####################################################################
####################################################################

Folder Lab2 should be placed within spark-examples to run.

Either:
-Run from Lab2 Folder          > ./test.sh
-Run directly from Lab2 Folder > spark-submit ./kmeans_2.py FiltData.csv